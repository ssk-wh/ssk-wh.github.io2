#ifndef GREETER_H
#define GREETER_H

#include <QWidget>

class QLineEdit;
class QVBoxLayout;
class QListView;
class QComboBox;
class QPushButton;

namespace QLightDM {
class Greeter;
class SessionsModel;
class UsersModel;
}

class Greeter : public QWidget
{
public:
    explicit Greeter(QWidget *parent = nullptr);

    void initUI();
    void initConnections();

public Q_SLOTS:
    void onLogin();
    void onAuthenticationComplete();
    void onShowPrompt(const QString &text, int type);
    void onShowMessage(QString text, int type);

private:
    QVBoxLayout *m_layout;
    QLineEdit *passwordEdit;
    QListView *m_userList;
    QComboBox *m_sessionCbx;
    QPushButton *m_loginBtn;

    QLightDM::Greeter *m_greeter;
};

#endif // GREETER_H
