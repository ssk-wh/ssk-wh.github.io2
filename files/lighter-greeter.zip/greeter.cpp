#include "greeter.h"

#include <QApplication>
#include <QLineEdit>
#include <QVBoxLayout>
#include <QPushButton>
#include <QListView>
#include <QComboBox>
#include <QDebug>

#include <QLightDM/Greeter>
#include <QLightDM/SessionsModel>
#include <QLightDM/UsersModel>

Greeter::Greeter(QWidget *parent)
    : QWidget(parent)
    , m_layout(new QVBoxLayout(this))
    , passwordEdit(new QLineEdit(this))
    , m_userList(new QListView(this))
    , m_sessionCbx(new QComboBox(this))
    , m_loginBtn(new QPushButton("Login", this))
    , m_greeter(new QLightDM::Greeter(this))
{
#ifdef QT_DEBUG
    if (!m_greeter->connectSync()) {
        qWarning() << "connect sync failed";
        close();
    }
#endif

    initUI();
    initConnections();
}

void Greeter::initUI()
{
    m_layout->addWidget(m_userList);
    m_layout->addWidget(passwordEdit);
    m_layout->addWidget(m_sessionCbx);
    m_layout->addWidget(m_loginBtn);

    m_userList->setModel(new QLightDM::UsersModel(this));
    m_userList->setCurrentIndex(QModelIndex());
    m_sessionCbx->setModel(new QLightDM::SessionsModel(this));
}

void Greeter::initConnections()
{
    connect(m_loginBtn, &QPushButton::clicked, this, &Greeter::onLogin);
    connect(m_greeter, &QLightDM::Greeter::authenticationComplete, this, &Greeter::onAuthenticationComplete);
    connect(m_greeter, &QLightDM::Greeter::showPrompt, this, &Greeter::onShowPrompt);
    connect(m_greeter, &QLightDM::Greeter::showMessage, this, &Greeter::onShowMessage);
}

void Greeter::onLogin()
{
    // cancel authentication
    if (m_greeter->inAuthentication()) {
        m_greeter->cancelAuthentication();
    }

    // start authentication
    QModelIndex currentIndex = m_userList->currentIndex();
    if (currentIndex.isValid() && !m_greeter->inAuthentication()) {
        qDebug() << "current user:" << currentIndex.data(QLightDM::UsersModel::NameRole).toString();
        m_greeter->authenticate(currentIndex.data(QLightDM::UsersModel::NameRole).toString());
    } else {
        qWarning() << "user list index is invalid or greeter is in authentication";
    }
}

void Greeter::onAuthenticationComplete()
{
    if (m_greeter->isAuthenticated()) {
        int index = m_sessionCbx->currentIndex();
        m_greeter->startSessionSync(m_sessionCbx->itemData(index, QLightDM::SessionsModel::IdRole).toString());
    } else {
        passwordEdit->setPlaceholderText("Incorrect password, please try again");
    }
}

void Greeter::onShowPrompt(const QString &text, int type) {
    qDebug() << text << static_cast<QLightDM::Greeter::PromptType>(type);
    m_greeter->respond(passwordEdit->text());
}

void Greeter::onShowMessage(QString text, int type)
{
    qDebug() << text << static_cast<QLightDM::Greeter::MessageType>(type);
}
