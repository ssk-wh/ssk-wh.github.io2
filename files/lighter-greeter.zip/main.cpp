#include <QApplication>

//#include <DWidgetUtil>
#include <DLog>

#include "greeter.h"

//DCORE_USE_NAMESPACE
//DWIDGET_USE_NAMESPACE

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

//    DLogManager::registerFileAppender();
//    DLogManager::registerConsoleAppender();

    Greeter g;
    g.setFixedSize(400, 300);
    g.show();

//    moveToCenter(&g);
    return a.exec();
}
