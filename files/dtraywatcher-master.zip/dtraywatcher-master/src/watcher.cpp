#include "watcher.h"
#include "service_handler.h"
#include "tray_panel.h"

#include <QDBusServiceWatcher>
#include <QDBusConnection>
#include <QDBusConnectionInterface>
#include <QDebug>
#include <QTimer>
#include <QVBoxLayout>

Watcher::Watcher(QObject *parent)
    : QObject(parent)
{

}

Watcher::~Watcher()
{

}

Watcher *Watcher::instance()
{
    static Watcher w;
    return &w;
}

bool Watcher::RegisterService(const QString &service)
{
    if (calledFromDBus()) {
        if (m_servicesMap.contains(service)) {
            sendErrorReply(QDBusError::Failed, QString("The service: %1 has already registered!").arg(service));
            return false;
        } else if (!service.startsWith("org.deepin.trayitem")) {
            sendErrorReply(QDBusError::BadAddress, QString("The service name must be startWith '%1'").arg("org.deepin.trayitem"));
            return false;
        }
    }

    auto watcher = new QDBusServiceWatcher(this);
    watcher->setConnection(QDBusConnection::sessionBus());
    watcher->addWatchedService(service);
    connect(watcher, &QDBusServiceWatcher::serviceRegistered, this, &Watcher::onServiceRegistered);
    connect(watcher, &QDBusServiceWatcher::serviceUnregistered, this, &Watcher::onServiceUnregistered);

    QDBusReply<bool> registered = watcher->connection().interface()->isServiceRegistered(service);

    if (registered.isValid() && registered.value()) {
        m_servicesMap.insert(service, watcher);

        qDebug() << "service: " << service << "registered";
        Q_EMIT ServiceRegistered(service);
        Q_EMIT ServicesChanged(Services());
    }

    return true;
}

QStringList Watcher::Services() const
{
    return m_servicesMap.keys();
}

// api版本
QString Watcher::Version() const
{
    return "1.0";
}

void Watcher::onServiceRegistered(const QString &service)
{
    auto watcher = qobject_cast<QDBusServiceWatcher *>(sender());
    if (!watcher || m_servicesMap.keys().contains(service))
        return;

    m_servicesMap.insert(service, watcher);

    qDebug() << "service: " << service << "registered";
    Q_EMIT ServiceRegistered(service);
    Q_EMIT ServicesChanged(Services());
}

void Watcher::onServiceUnregistered(const QString &service)
{
    if (!qobject_cast<QDBusServiceWatcher *>(sender()))
        return;

    auto watcher = m_servicesMap.take(service);
    m_servicesMap.remove(service);
    delete watcher;

    qDebug() << "service: " << service << "unregistered";
    Q_EMIT ServiceUnregistered(service);
    Q_EMIT ServicesChanged(Services());
}
