#include "tray_icon.h"
#include "service_handler.h"

#include <QDragEnterEvent>
#include <QDropEvent>
#include <QMimeData>

TrayIcon::TrayIcon(const QString &service, QWidget *parent)
    :DIconButton(parent)
    , m_handler(new ServiceHandler(service, this))
{
    DIconButton::setIcon(QIcon::fromTheme(m_handler->icon(), QIcon::fromTheme("application-x-desktop")));
    setIconSize(QSize(48, 48));
    setToolTip(m_handler->tips());
    setAcceptDrops(true);

    connect(m_handler, &ServiceHandler::tipsChanged, this, &DIconButton::setToolTip);
    connect(m_handler, &ServiceHandler::iconChanged, this, QOverload<const QString &>::of(&TrayIcon::setIcon));
    connect(this, &DIconButton::clicked, this, [ = ] {
        m_handler->activate();
        Q_EMIT pushPopup(m_handler->itemApplet());
    });
}

void TrayIcon::setIcon(const QString &icon)
{
    DIconButton::setIcon(QIcon(icon));
}

bool TrayIcon::isContentValid()
{
    return m_handler->isContentValid();
}

void TrayIcon::dragEnterEvent(QDragEnterEvent *event)
{
    if (m_handler->acceptFormats(event->mimeData()->formats())) {
        event->setDropAction(Qt::CopyAction);
        event->accept();
    } else {
        event->setDropAction(Qt::IgnoreAction);
    }
}

void TrayIcon::dropEvent(QDropEvent *event)
{
    QByteArray buf = event->mimeData()->data("text/uri-list");
    qDebug() << buf << QString::fromLocal8Bit(buf) << QString::fromUtf8(buf)
             << QUrl(buf).toLocalFile() << QString(buf.toStdString().data());
    Map map;
    for (auto f : event->mimeData()->formats()) {
        map.insert(f, event->mimeData()->data(f));
    }
    m_handler->handleMimeData(map);
}
