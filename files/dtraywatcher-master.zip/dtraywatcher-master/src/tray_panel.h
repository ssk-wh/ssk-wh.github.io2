#ifndef TRAY_PANEL_H
#define TRAY_PANEL_H

#include <QMap>

#include <DBlurEffectWidget>

DWIDGET_USE_NAMESPACE
class QHBoxLayout;
class TrayPopup;
class QTimer;
class TrayIcon;
//class ServiceHandler;
class TrayPanel : public DBlurEffectWidget
{
    Q_OBJECT
public:
    explicit TrayPanel(QWidget *parent = nullptr);
    ~TrayPanel();

public Q_SLOTS:
    void addItem(const QString &service);
    void removeItem(const QString &service);

protected:
    bool eventFilter(QObject *watched, QEvent *event) override;

private:
    QHBoxLayout *m_layout;
    TrayPopup *m_popup;
    QMap<QString, TrayIcon *> m_servicesMap;
};

#endif // TRAY_PANEL_H
