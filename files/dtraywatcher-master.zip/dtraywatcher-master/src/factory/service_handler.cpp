#include "service_handler.h"
#include "c_text.h"
#include "c_item.h"
#include "c_switch_button.h"
#include "c_slider.h"
#include "c_title_item.h"
#include "c_separator.h"

#include <QDBusInterface>
#include <QDBusArgument>
#include <QVariantMap>
#include <QDebug>
#include <QWidget>
#include <QVBoxLayout>

#define TRAY_SERVICE_PATH "/ItemNotifier"
#define TRAY_SERVICE_INTERFACE "org.deepin.trayitem"

ServiceHandler::ServiceHandler(const QString &service, QObject *parent)
    : QObject(parent)
    , m_service(service)
    , m_itemApplet(nullptr)
    , m_vLayout(nullptr)
    , m_inter(new __ItemNotifier(service, TRAY_SERVICE_PATH, QDBusConnection::sessionBus(), this))
    , m_contentValid(!m_inter->items().isEmpty())
{
    connect(m_inter, &__ItemNotifier::tipsChanged, this, &ServiceHandler::tipsChanged);
    connect(m_inter, &__ItemNotifier::iconChanged, this, &ServiceHandler::iconChanged);
    connect(m_inter, &__ItemNotifier::itemsChanged, this, [ = ] (const QStringList &list) {
        bool newContentValid = !m_inter->items().isEmpty();
        if (m_contentValid == newContentValid)
            return;

        m_contentValid = newContentValid;
        Q_EMIT contentValidChanged(newContentValid);
    });
}

ServiceHandler::~ServiceHandler()
{
    if (m_itemApplet) {
        delete m_itemApplet;
        m_itemApplet = nullptr;
    }

    for (auto f : m_itemMap.values()) {
        delete f;
    }
    m_itemMap.clear();
}

QWidget *ServiceHandler::itemApplet()
{
    // 未调用前不创建，减少不必要的内存
    if (!m_itemApplet) {
        m_itemApplet = new QWidget;
        m_itemApplet->setMinimumWidth(300);
        m_vLayout = new QVBoxLayout(m_itemApplet);

        connect(m_inter, &__ItemNotifier::itemsChanged, this, &ServiceHandler::handleItemsChanged);
        handleItemsChanged(m_inter->items());
        // TODO 隐藏后可以不用再关注服务中Control部分的变化(显示的时候刷新一次并重新监听)，不过监听了也没什么大不了的
    }

    return m_itemApplet;
}

QString ServiceHandler::tips() const
{
    return m_inter->tips();
}

QString ServiceHandler::icon() const
{
    return m_inter->icon();
}

bool ServiceHandler::isContentValid()
{
    return m_contentValid;
}

void ServiceHandler::activate()
{
    m_inter->activateQueued();
}

bool ServiceHandler::acceptFormats(const QStringList &formats)
{
    return m_inter->acceptFormats(formats);
}

void ServiceHandler::handleMimeData(Map map)
{
    m_inter->handleMimeData(map);
}

ServiceType ServiceHandler::getControlType(const QString &path)
{
    QDBusInterface inter(m_service, path, TRAY_SERVICE_INTERFACE, QDBusConnection::sessionBus());
    return static_cast<ServiceType>(inter.property("type").toInt());
}

AbstractCreator *ServiceHandler::getControlCreator(ServiceType type, const QString &service, const QString &path)
{
#define CASE_IMPL(enum_type)     case ServiceType::enum_type:\
    item = new C_##enum_type(service, path, this);\
    break;

    AbstractCreator *item = nullptr;
    switch (type) {
    CASE_IMPL(Text);
    CASE_IMPL(Item);
    CASE_IMPL(TitleItem);
    CASE_IMPL(Slider);
    CASE_IMPL(SwitchButton);
    CASE_IMPL(Separator);
    default:
        qWarning() << "ERROR! unimpl type: " << type;
        break;
    }
    return item;
}

void ServiceHandler::handleItemsChanged(const QStringList &paths)
{
    if (!m_itemApplet || !m_vLayout || paths.isEmpty())
        return;

    QStringList list_to_add;
    for (auto path : paths) {
        if (!m_paths.contains(path))
            list_to_add.append(path);
    }

    QStringList list_to_remove;
    for (auto path : m_paths) {
        if (!paths.contains(path)) {
            list_to_remove.append(path);
            qDebug() << "path: " << path << " removed";
        }
    }

    for (auto path : list_to_add) {
        auto type = getControlType(path);
        auto factory = getControlCreator(type, m_service, path);
        if (factory) {
            m_itemMap.insert(path, factory);
            qDebug() << "path: " << path << " added";
        } else {
            qWarning() << "unimpled type: " << type;
            break;
        }
    }

    for (auto path : list_to_remove) {
        auto factory = m_itemMap.take(path);
        if (factory) {
            auto w = factory->create();
            if (w) {
                w->setVisible(false);
                delete w;
            }
            m_itemMap.remove(path);
            delete factory;
        }
    }

    // 先隐藏原有的widget
    for (int i = 0; i < m_vLayout->count(); ++i) {
        auto w = m_vLayout->itemAt(i)->widget();
        Q_ASSERT(w);

        w->setVisible(false);
        qDebug() << "removed, size hint:" << m_itemApplet->sizeHint();
        m_vLayout->removeWidget(w);
        m_itemApplet->setFixedHeight(m_itemApplet->sizeHint().height()); // TODO 调整高度时可以采用动画平滑过度
    }

    // 按照先后顺序重新添加所有的widget
    for (auto path : paths) {
        auto factory = m_itemMap[path];
        if(factory) {
            auto w = factory->create();
            w->setParent(m_itemApplet);
            m_vLayout->addWidget(w);
            w->setVisible(true);
            m_itemApplet->setFixedHeight(m_itemApplet->sizeHint().height()); // TODO 调整高度时可以采用动画平滑过度
        }
    }

    m_paths = paths;
}
