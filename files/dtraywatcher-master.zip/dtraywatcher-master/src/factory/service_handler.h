#ifndef SERVICE_HANDLER_H
#define SERVICE_HANDLER_H

#include <QObject>
#include <QDBusMessage>
#include <QMap>

#include "item_notifier_interface.h"

#include "../include/util.h"

//enum ServiceType {
//    Text = 0,
//    Item,
//    TitleItem,
//    Slider,
//    SwitchButton,
//    Separator
//};

class AbstractCreator;
class QVBoxLayout;
class ServiceHandler : public QObject
{
    Q_OBJECT
public:
    explicit ServiceHandler(const QString &service, QObject *parent = nullptr);
    ~ ServiceHandler();

    QWidget *itemApplet();
    QString tips() const;
    QString icon() const;

    bool isContentValid();
    void activate();
    bool acceptFormats(const QStringList &formats);
    void handleMimeData(Map map);

Q_SIGNALS:
    void tipsChanged(const QString &tips);
    void iconChanged(const QString &icon);
    void contentValidChanged(bool valid);

private:
    ServiceType getControlType(const QString &interface);
    AbstractCreator *getControlCreator(ServiceType type, const QString &service, const QString &path);

private Q_SLOTS:
    void handleItemsChanged(const QStringList &items);

private:
    QStringList m_paths;
    QString m_service;

    QWidget *m_itemApplet;
    QVBoxLayout *m_vLayout;

    QMap<QString, AbstractCreator *> m_itemMap;

    __ItemNotifier *m_inter;

    bool m_contentValid;
};

#endif // SERVICE_HANDLER_H
