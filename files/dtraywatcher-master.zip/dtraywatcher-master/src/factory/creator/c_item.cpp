#include "c_item.h"

//#include <QLabel>
//#include <QDebug>
//#include <QDBusConnection>
//#include <QVariantMap>
//#include <QDBusArgument>
//#include <QPalette>

//#define PROPERTY_TEXT "text"

#include <QWidget>

/* QString      title       标题
 * int          type        控件类型，Item类型是1
 *
 */
C_Item::C_Item(const QString &service, const QString &path, QObject *parent)
    : AbstractCreator(service, path, parent)
    , m_widget(nullptr)
    , m_inter(new __TrayItem(service, path, QDBusConnection::sessionBus(), this))
{

}

QWidget *C_Item::create()
{
    if (!m_widget) {
        m_widget = new QWidget;
//        m_label->setForegroundRole(QPalette::BrightText);
//        connect(m_inter, &__TrayText::textChanged, m_label, &QLabel::setText);
    }

    return m_widget;
}
