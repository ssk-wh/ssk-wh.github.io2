#include "c_separator.h"

#include <QLabel>

/* QString      title       标题
 * int          type        控件类型，Separator类型是5
 *
 * int          direction   0: 横向, 1:竖向
 */
C_Separator::C_Separator(const QString &service, const QString &path, QObject *parent)
    : AbstractCreator(service, path, parent)
    , m_label(nullptr)
{

}

QWidget *C_Separator::create()
{
    if (!m_label) {
        m_label = new QLabel;
        m_label->setBackgroundRole(QPalette::Base);
        m_label->setFixedHeight(2);
    }

    return m_label;
}
