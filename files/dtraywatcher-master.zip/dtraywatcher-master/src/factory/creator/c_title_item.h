#ifndef C_TITLE_ITEM_H
#define C_TITLE_ITEM_H

#include "abstract_creator.h"
#include "tray_titleitem_interface.h"

class QLabel;
class C_TitleItem : public AbstractCreator
{
public:
    explicit C_TitleItem(const QString &service, const QString &path, QObject *parent = nullptr);

    virtual QWidget *create();

private:
    QWidget *m_widget;
    __TrayTitleItem *m_inter;
};

#endif // C_TITLE_ITEM_H
