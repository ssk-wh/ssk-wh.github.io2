#ifndef CREATOR_H
#define CREATOR_H

#include <QObject>

class AbstractCreator : public QObject
{
public:
    explicit AbstractCreator(const QString &service, const QString &path, QObject *parent = nullptr)
        : QObject (parent)
        , m_service(service)
        , m_path(path) { }

    // 随着 Factory 一起销毁
    virtual QWidget *create() = 0;

protected:
    // TODO 是否有必要提供这俩接口
    inline const QString &service() {return m_service;}
    inline const QString &path() {return m_path;}

private:
    QString m_service;
    QString m_path;
};

#endif // CREATOR_H
