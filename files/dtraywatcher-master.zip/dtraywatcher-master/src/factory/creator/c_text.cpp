#include "c_text.h"

#include <QLabel>

/* QString      title       标题
 * int          type        控件类型，Text类型是0
 *
 * QString      text        文本内容
 */
C_Text::C_Text(const QString &service, const QString &path, QObject *parent)
    : AbstractCreator(service, path, parent)
    , m_label(nullptr)
    , m_inter(new __TrayText(service, path, QDBusConnection::sessionBus(), this))
{

}

QWidget *C_Text::create()
{
    if (!m_label) {
        m_label = new QLabel(m_inter->text());
        m_label->setForegroundRole(QPalette::BrightText);
        connect(m_inter, &__TrayText::textChanged, m_label, &QLabel::setText);
    }

    return m_label;
}
