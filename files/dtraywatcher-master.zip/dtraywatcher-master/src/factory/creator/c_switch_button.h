#ifndef C_SWITCH_BUTTON_H
#define C_SWITCH_BUTTON_H

#include "abstract_creator.h"
#include "tray_switchbutton_interface.h"

class QWidget;
class C_SwitchButton : public AbstractCreator
{
public:
    explicit C_SwitchButton(const QString &service, const QString &path, QObject *parent = nullptr);

    virtual QWidget *create();

private:
    QWidget *m_widget;
    __TraySwitchButton *m_inter;
};

#endif // C_SWITCH_BUTTON_H
