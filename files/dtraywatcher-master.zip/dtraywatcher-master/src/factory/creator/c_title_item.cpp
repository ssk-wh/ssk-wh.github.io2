#include "c_title_item.h"

#include <QLabel>
#include <QDebug>
#include <QHBoxLayout>

#include <DFontSizeManager>

DWIDGET_USE_NAMESPACE

/* QString      title       标题,居左显示
 * int          type        控件类型，TitleItem类型是2
 *
 * QString      content     文本内容，巨右显示
 */
C_TitleItem::C_TitleItem(const QString &service, const QString &path, QObject *parent)
    : AbstractCreator(service, path, parent)
    , m_widget(nullptr)
    , m_inter(new __TrayTitleItem(service, path, QDBusConnection::sessionBus(), this))
{

}

QWidget *C_TitleItem::create()
{
    if (!m_widget) {
        m_widget = new QWidget;

        QHBoxLayout *layout = new QHBoxLayout(m_widget);
        QLabel *left = new QLabel(m_widget);
        QLabel *right = new QLabel(m_widget);
        left->setForegroundRole(QPalette::BrightText);
        right->setForegroundRole(QPalette::BrightText);
        left->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        right->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
        left->setText(m_inter->title());
        right->setText(m_inter->content());
        DFontSizeManager::instance()->bind(left, DFontSizeManager::T4, QFont::Medium);
        DFontSizeManager::instance()->bind(right, DFontSizeManager::T8, QFont::Medium);
        connect(m_inter, &__TrayTitleItem::titleChanged, left, &QLabel::setText);
        connect(m_inter, &__TrayTitleItem::contentChanged, right, &QLabel::setText);

        layout->addWidget(left, Qt::AlignLeft);
        layout->addWidget(right, Qt::AlignRight);
    }

    return m_widget;
}
