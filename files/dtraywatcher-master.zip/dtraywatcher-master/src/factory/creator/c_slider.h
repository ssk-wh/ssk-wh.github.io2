#ifndef C_SLIDER_H
#define C_SLIDER_H

#include "abstract_creator.h"
#include "tray_slider_interface.h"

class VolumeSlider;
class C_Slider : public AbstractCreator
{
public:
    explicit C_Slider(const QString &service, const QString &path, QObject *parent = nullptr);

    virtual QWidget *create();

private:
    VolumeSlider *m_slider;
    __TraySlider *m_inter;
};

#endif // C_SLIDER_H
