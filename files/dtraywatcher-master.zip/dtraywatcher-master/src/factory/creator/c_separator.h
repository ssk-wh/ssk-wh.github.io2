#ifndef C_SEPARATOR_H
#define C_SEPARATOR_H

#include "abstract_creator.h"

class QLabel;
/**
 * @brief The C_SEPARATOR class
 * @note 分割线
 * @todo 支持横向和竖向
 */
class C_Separator : public AbstractCreator
{
public:
    explicit C_Separator(const QString &service, const QString &path, QObject *parent = nullptr);

    virtual QWidget *create();

private:
    QLabel *m_label;
};

#endif // C_SEPARATOR_H
