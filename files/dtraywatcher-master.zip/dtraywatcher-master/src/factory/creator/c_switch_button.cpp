#include "c_switch_button.h"

#include <QPushButton>
#include <QHBoxLayout>
#include <QLabel>

#include <DSwitchButton>

DWIDGET_USE_NAMESPACE

/* QString      title       标题
 * int          type        控件类型，SwitchButton类型是4
 *
 *  bool         open        开关状态
 */

C_SwitchButton::C_SwitchButton(const QString &service, const QString &path, QObject *parent)
    : AbstractCreator(service, path, parent)
    , m_widget(nullptr)
    , m_inter(new __TraySwitchButton(service, path, QDBusConnection::sessionBus(), this))
{

}

QWidget *C_SwitchButton::create()
{
   if (!m_widget) {
       m_widget = new QWidget;
       QHBoxLayout *layout = new QHBoxLayout(m_widget);
       layout->setContentsMargins(0, 0, 0, 0);

       QLabel *title = new QLabel(m_widget);
       title->setAlignment(Qt::AlignLeft | Qt::AlignCenter);
       title->setText(m_inter->title());
       title->setForegroundRole(QPalette::BrightText);
       connect(m_inter, &__TraySwitchButton::titleChanged, title, &QLabel::setText);

       DSwitchButton *button = new DSwitchButton(m_widget);
       button->setChecked(m_inter->open());
       connect(m_inter, &__TraySwitchButton::openChanged, button, &DSwitchButton::setChecked);
       connect(button, &DSwitchButton::checkedChanged, m_inter, &__TraySwitchButton::setOpen);

       layout->addWidget(title, 0, Qt::AlignLeft);
       layout->addWidget(button, 0, Qt::AlignRight);
   }

   return m_widget;
}
