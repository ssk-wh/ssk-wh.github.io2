#ifndef C_TEXT_H
#define C_TEXT_H

#include "abstract_creator.h"
#include "tray_text_interface.h"

class QLabel;
class C_Text : public AbstractCreator
{
public:
    explicit C_Text(const QString &service, const QString &path, QObject *parent = nullptr);

    virtual QWidget *create();

private:
    QLabel *m_label;
    __TrayText *m_inter;
};

#endif // C_TEXT_H
