#ifndef C_ITEM_H
#define C_ITEM_H

#include "abstract_creator.h"
#include "tray_item_interface.h"

class QWidget;
class C_Item : public AbstractCreator
{
public:
    explicit C_Item(const QString &service, const QString &path, QObject *parent = nullptr);

    virtual QWidget *create();

private:
    QWidget *m_widget;
    __TrayItem *m_inter;
};

#endif // C_ITEM_H

// TODO 支持特殊的list控件
