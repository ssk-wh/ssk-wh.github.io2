#include "c_slider.h"
#include "volumeslider.h"

#include <QDebug>

/* QString      title       标题
 * int          type        控件类型，Slider类型是3
 *
 * int          min         最小值
 * int          max         最大值
 * int          value       当前值
 */
C_Slider::C_Slider(const QString &service, const QString &path, QObject *parent)
    : AbstractCreator(service, path, parent)
    , m_slider(nullptr)
    , m_inter(new __TraySlider(service, path, QDBusConnection::sessionBus(), this))
{

}

QWidget *C_Slider::create()
{
    if (!m_slider) {
        m_slider = new VolumeSlider;
        m_slider->setMinimum(m_inter->min());
        m_slider->setMaximum(m_inter->max());
        m_slider->setValue(m_inter->value());
        connect(m_inter, &__TraySlider::minChanged, m_slider, &VolumeSlider::setMinimum);
        connect(m_inter, &__TraySlider::maxChanged, m_slider, &VolumeSlider::setMaximum);
        connect(m_inter, &__TraySlider::valueChanged, m_slider, &VolumeSlider::setValue);
        connect(m_slider, &VolumeSlider::valueChanged, m_inter, &__TraySlider::setValue);
    }

    return m_slider;
}
