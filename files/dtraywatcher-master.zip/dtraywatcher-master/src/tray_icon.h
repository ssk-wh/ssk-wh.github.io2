#ifndef TRAY_ICON_H
#define TRAY_ICON_H
#include <DIconButton>

DWIDGET_USE_NAMESPACE

class QDragEnterEvent;
class QDropEvent;
class ServiceHandler;
class TrayIcon : public DIconButton
{
    Q_OBJECT
public:
    explicit TrayIcon(const QString &service, QWidget *parent = nullptr);

    void setFormats(const QStringList &list);
    bool isContentValid();

public Q_SLOTS:
    void setIcon(const QString &icon);

Q_SIGNALS:
    void removed();
    void pushPopup(QWidget *popup);

protected:
    void dragEnterEvent(QDragEnterEvent *event) override;
    void dropEvent(QDropEvent *event) override;

private:
    ServiceHandler *m_handler;
};

#endif // TRAY_ICON_H
