#include "tray_panel.h"
#include "tray_popup.h"
#include "tray_icon.h"

#include <QHBoxLayout>
#include <QIcon>
#include <QApplication>
#include <QPushButton>

TrayPanel::TrayPanel(QWidget *parent)
    : DBlurEffectWidget(parent)
    , m_layout(new QHBoxLayout(this))
    , m_popup(new TrayPopup)
{
    m_layout->setContentsMargins(0, 0, 0, 0);

    m_popup->setShadowBlurRadius(20);
    m_popup->setRadius(18);
    m_popup->setShadowYOffset(2);
    m_popup->setShadowXOffset(0);
    m_popup->setArrowWidth(18);
    m_popup->setArrowHeight(10);

    this->installEventFilter(this);
}

TrayPanel::~TrayPanel()
{
    delete m_popup;
}

void TrayPanel::addItem(const QString &service)
{
    // TODO 丢到线程中检查服务是否valid，避免影响主线程启动速度

    TrayIcon *iconButton = new TrayIcon(service, this);
    connect(iconButton, &TrayIcon::pushPopup, this, [ = ] (QWidget *popup) {
        // 显示插件内容
        auto w = m_popup->getContent();
        if (w) {
            w->setVisible(false);
        }

        // 插件无界面
        if (!iconButton->isContentValid()) {
            m_popup->hide();
            return;
        }

        m_popup->setContent(popup);
        auto pos = mapToGlobal(iconButton->pos());
        m_popup->show(QPoint(pos.x() + (iconButton->width() / 2), this->pos().y()));

        // TODO 插件内容正在展示时，此时服务变更为无界面的形式，应做隐藏(插件内容发生变化，均能正常响应)
    });

    m_layout->addWidget(iconButton);

    m_servicesMap.insert(service, iconButton);

    // TODO 触发界面调整，否则按钮分布不均匀，应该是DTK的bug
    QMetaObject::invokeMethod(this, [ = ] {
        this->setFixedSize(this->size() + QSize(1, 1));
        this->setFixedSize(this->size() - QSize(1, 1));
    }, Qt::QueuedConnection);
}

void TrayPanel::removeItem(const QString &service)
{
    auto button = m_servicesMap.take(service);
    m_servicesMap.remove(service);

    // handler创建的widget会跟随handler销毁
    delete button;
    button = nullptr;

    // TODO 移除对应icon
}

bool TrayPanel::eventFilter(QObject *watched, QEvent *event)
{
    if (watched == this && (event->type() == QEvent::FocusOut || event->type() == QEvent::Hide)) {
        m_popup->setVisible(false);
    }

    return DBlurEffectWidget::eventFilter(watched, event);
}
