#ifndef SERVICESWITCHBUTTON_H
#define SERVICESWITCHBUTTON_H

#include <QObject>

#include "util.h"

class ServiceSwitchButton : public QObject
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.deepin.trayitem")

public:
    explicit ServiceSwitchButton(const QString &title, QObject *parent = nullptr);

    Q_PROPERTY(int type READ type)
    virtual inline int type() {return ServiceType::SwitchButton;}

    Q_PROPERTY(QString title READ title)
    inline QString &title() {return m_title;}

    Q_PROPERTY(bool open READ open WRITE setOpen)
    inline bool open() {return m_open;}
    void setOpen(bool on);

Q_SIGNALS:
    void titleChanged(const QString &text);
    void openChanged(bool on);

private:
    QString m_title;
    bool m_open;
};

#endif // SERVICESWITCHBUTTON_H
