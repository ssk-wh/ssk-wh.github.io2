#ifndef SERVICE_ITEM_H
#define SERVICE_ITEM_H

#include <QObject>

#include "util.h"

class ServiceItem : public QObject
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.deepin.trayitem")

public:
    explicit ServiceItem(const QString &text, QObject *parent = nullptr);

    Q_PROPERTY(int type READ type)
    virtual inline int type() {return ServiceType::Text;}

    Q_PROPERTY(QString text READ text)
    inline const QString &text() {return m_text;}
    void setText(const QString &text);

    Q_PROPERTY(QString actionIcon READ actionIcon)
    inline QString actionIcon() {return m_actionIcon;}
    void setActionIcon(QString actionIcon);

    Q_PROPERTY(QString leftIcon READ leftIcon)
    inline QString leftIcon() {return m_leftIcon;}
    void setLeftIcon(QString leftIcon);

    Q_PROPERTY(QString rightIcon READ leftIcon)
    inline QString rightIcon() {return m_rightIcon;}
    void setRightIcon(QString rightIcon);

    Q_PROPERTY(QString hoverIcon READ hoverIcon)
    inline QString hoverIcon() {return m_hoverIcon;}
    void setHoverIcon(QString hoverIcon);

Q_SIGNALS:
    void textChanged(const QString &text);
    void actionIconChanged(const QString &icon);
    void leftIconChanged(const QString &icon);
    void rightIconChanged(const QString &icon);
    void hoverIconChanged(const QString &icon);

private:
    QString m_text;
    QString m_actionIcon;
    QString m_leftIcon;
    QString m_rightIcon;
    QString m_hoverIcon;
};

#endif // SERVICE_ITEM_H
