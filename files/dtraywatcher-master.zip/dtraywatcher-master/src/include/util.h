#ifndef UTIL_H
#define UTIL_H

#include <QVector>
#include <QMap>
#include <QDebug>
#include <QObject>
#include <QDBusConnection>

static QMap<QString, QObject *> map;

// 控件类型定义
enum ServiceType {
    Text = 0,               // 文本
    Item = 1,               // 带左右侧图标，中间显示文字
    TitleItem = 2,          // 带左右侧文字
    Slider = 3,             // 滑动条
    SwitchButton = 4,       // 带标题的开关按钮
    Separator = 5,          // 分割线
    Reserve                 // 增加类型需要在Reserve之前
};

namespace Util {
// 返回将要注册的path路径,需要确保不重复出现
inline QString Register(QObject *obj) {
    static QStringList list;
    static int index = 0;
    index ++;
    QString path = "/Item/" + QString::number(index);
    bool ok = QDBusConnection::sessionBus().registerObject(path, obj, QDBusConnection::ExportAllProperties | QDBusConnection::ExportAllSignals);
    if (!ok) {
        qWarning() << "register failed";
    }

    return path;
}

// 返回将要注册的path路径,需要确保不重复出现
inline void Unregister(const QString &path) {
    QDBusConnection::sessionBus().unregisterObject(path);
}

inline QString bind(QObject* obj) {
    if (map.values().contains(obj)) {
        qWarning() << "bind repeat";
        return QString();
    }

    auto path =  Register(obj);
    // TODO auto unbind
    map.insert(path, obj);
    return path;
}

inline void unbind(const QString &path) {
    if (map.contains(path)) {
        auto obj = map.value(path);
        if (obj->inherits("QObject")) {
            delete obj;
        }
        map.remove(path);
    }
}
}
#endif // UTIL_H
