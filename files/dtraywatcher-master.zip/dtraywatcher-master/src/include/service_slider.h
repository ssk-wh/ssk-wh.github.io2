#ifndef SERVICE_SLIDER_H
#define SERVICE_SLIDER_H

#include <QObject>

#include "util.h"

class ClientAdapter;
class ServiceSlider : public QObject
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.deepin.trayitem")

    friend class ClientAdapter;

public:
    explicit ServiceSlider(QObject *parent = nullptr);

    Q_PROPERTY(int type READ type)
    virtual inline int type() {return ServiceType::Slider;}

    Q_PROPERTY(int min READ min)
    inline int min() {return m_min;}
    void setMin(int min);

    Q_PROPERTY(int max READ max)
    inline int max() {return m_max;}
    void setMax(int max);

    Q_PROPERTY(int value READ value WRITE setValue)
    inline int value() {return m_value;}
    void setValue(int value);

    Q_PROPERTY(bool mute READ mute WRITE setMute)
    inline int mute() {return m_mute;}
    void setMute(int mute);

    Q_PROPERTY(QString leftIcon READ leftIcon)
    inline QString leftIcon() {return m_leftIcon;}
    void setLeftIcon(QString leftIcon);

    Q_PROPERTY(QString rightIcon READ leftIcon)
    inline QString rightIcon() {return m_rightIcon;}
    void setRightIcon(QString rightIcon);

Q_SIGNALS:
    void minChanged(int min);
    void maxChanged(int max);
    void valueChanged(int value);
    void muteChanged(bool mute);
    void leftIconChanged(const QString &icon);
    void rightIconChanged(const QString &icon);

private:
    int m_min;
    int m_max;
    int m_value;
    bool m_mute;
    QString m_leftIcon;
    QString m_rightIcon;
};
#endif // SERVICE_SLIDER_H
