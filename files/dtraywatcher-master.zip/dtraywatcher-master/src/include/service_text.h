#ifndef SERVICE_TEXT_H
#define SERVICE_TEXT_H

#include <QObject>

#include "util.h"

class ServiceText : public QObject
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.deepin.trayitem")

public:
    explicit ServiceText(const QString &text, QObject *parent = nullptr);

    Q_PROPERTY(int type READ type)
    virtual inline int type() {return ServiceType::Text;}

    Q_PROPERTY(QString text READ text)
    inline const QString &text() {return m_text;}
    void setText(const QString &text);

Q_SIGNALS:
    void textChanged(const QString &text);

private:
    QString m_text;
};

#endif // SERVICE_TEXT_H
