#ifndef SERVICE_TITLE_ITEM_H
#define SERVICE_TITLE_ITEM_H

#include <QObject>

#include "util.h"

class ServiceTitleItem : public QObject
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.deepin.trayitem")

public:
    explicit ServiceTitleItem(const QString &title, const QString &content, QObject *parent = nullptr);

    Q_PROPERTY(int type READ type)
    virtual inline int type() {return ServiceType::TitleItem;}

    Q_PROPERTY(QString title READ title)
    inline const QString &title() {return m_title;}
    void setTitle(const QString &title);

    Q_PROPERTY(QString content READ content)
    inline const QString &content() {return m_content;}
    void setContent(const QString &content);

Q_SIGNALS:
    void titleChanged(const QString &text);
    void contentChanged(const QString &content);

private:
    QString m_title;
    QString m_content;
};
#endif // SERVICE_TITLE_ITEM_H
