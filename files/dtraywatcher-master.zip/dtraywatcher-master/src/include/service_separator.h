#ifndef SEPARATOR_H
#define SEPARATOR_H

#include <QObject>

#include "util.h"

class ServiceSeparator : public QObject
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.deepin.trayitem")

public:
    explicit ServiceSeparator(QObject *parent = nullptr);

    Q_PROPERTY(int type READ type)
    virtual inline int type() {return ServiceType::Separator;}
};

#endif // SEPARATOR_H
