#ifndef DBUS_ADAPTER_H
#define DBUS_ADAPTER_H

#include <QtDBus/QtDBus>
#include <QMap>

#include "watcher.h"

class DBusAdapter : public QDBusAbstractAdaptor
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Service", "org.deepin.traywatcher")
    Q_CLASSINFO("D-Bus Path", "/traywatcher")
    Q_CLASSINFO("D-Bus Interface", "org.deepin.traywatcher")
    Q_CLASSINFO("D-Bus Introspection", ""
                                       "  <interface name=\"org.deepin.traywatcher\">\n"
                                       "    <property access=\"read\" type=\"as\" name=\"Services\"/>\n"
                                       "    <property access=\"read\" type=\"s\" name=\"Version\"/>\n"
                                       "    <method name=\"RegisterService\">"
                                       "        <arg name=\"service\" type=\"s\" direction=\"in\"/>"
                                       "        <arg name=\"ok\" type=\"b\" direction=\"out\"/>"
                                       "    </method>"
                                       "    <signal name=\"ServiceRegistered\">"
                                       "        <arg type=\"s\"/>"
                                       "    </signal>"
                                       "    <signal name=\"ServiceUnregistered\">"
                                       "        <arg type=\"s\"/>"
                                       "    </signal>"
                                       "  </interface>\n"
                                       "")

    Q_PROPERTY(QStringList Services READ Services NOTIFY ServicesChanged)
    Q_PROPERTY(QString Version READ Version)

public:
    explicit DBusAdapter(Watcher *manager);
    virtual ~DBusAdapter();

    Watcher *parent() const;

public Q_SLOTS:
    bool RegisterService(const QString &service);

    QStringList Services() const;

    QString Version() const;

Q_SIGNALS:
    void ServiceRegistered(const QString &service);
    void ServiceUnregistered(const QString &service);
    void ServicesChanged(const QStringList &services);
};

#endif // DBUS_ADAPTER_H
