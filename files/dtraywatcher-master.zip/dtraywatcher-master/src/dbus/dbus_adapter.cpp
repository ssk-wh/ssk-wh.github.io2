#include "dbus_adapter.h"
#include "service_handler.h"

#include <QDBusServiceWatcher>
#include <QDBusConnection>
#include <QDBusConnectionInterface>
#include <QDebug>
#include <QWidget>

DBusAdapter::DBusAdapter(Watcher *manager)
    : QDBusAbstractAdaptor(manager)
{
    connect(manager, &Watcher::ServicesChanged, this, &DBusAdapter::ServicesChanged);
    connect(manager, &Watcher::ServiceRegistered, this, &DBusAdapter::ServiceRegistered);
    connect(manager, &Watcher::ServiceUnregistered, this, &DBusAdapter::ServiceUnregistered);
}

DBusAdapter::~DBusAdapter()
{

}

Watcher *DBusAdapter::parent() const
{
    return static_cast<Watcher *>(QObject::parent());
}

bool DBusAdapter::RegisterService(const QString &service)
{
    return parent()->RegisterService(service);
}

QStringList DBusAdapter::Services() const
{
    return parent()->Services();
}

QString DBusAdapter::Version() const
{
    return parent()->Version();
}
