// SPDX-FileCopyrightText: 2021 - 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

#ifndef MAP_H
#define MAP_H

#include <QMap>
#include <QByteArray>
#include <QDBusMetaType>

using Map = QMap<QString, QString>;
Q_DECLARE_METATYPE(Map);

void registerMapMetaType();

#endif // MAP_H
