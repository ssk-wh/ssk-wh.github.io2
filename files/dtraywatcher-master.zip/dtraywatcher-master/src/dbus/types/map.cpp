// SPDX-FileCopyrightText: 2021 - 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

#include "map.h"

void registerMapMetaType()
{
    qRegisterMetaType<Map>("Map");
    qDBusRegisterMetaType<Map>();
}
