#ifndef TRAY_POPUP_H
#define TRAY_POPUP_H

#include <DArrowRectangle>
#include <DRegionMonitor>
#include <DWindowManagerHelper>

DWIDGET_USE_NAMESPACE
DGUI_USE_NAMESPACE

class TrayPopup : public Dtk::Widget::DArrowRectangle
{
    Q_OBJECT

public:
    explicit TrayPopup(QWidget *parent = 0);
    ~TrayPopup();

    bool model() const;

    void setContent(QWidget *content);

public slots:
    void show(const QPoint &pos, const bool model = false);
    void show(const int x, const int y);
    void hide();

signals:
    void accept() const;
    void unusedSignal();

protected:
    void showEvent(QShowEvent *e);
    void enterEvent(QEvent *e);
    bool eventFilter(QObject *o, QEvent *e);
    void blockButtonRelease();

private slots:
    void onGlobMouseRelease(const QPoint &mousePos, const int flag);
    void compositeChanged();
    void ensureRaised();

private:
    bool m_model;
    QPoint m_lastPoint;

    DRegionMonitor *m_regionInter;
    DWindowManagerHelper *m_wmHelper;
    bool m_enableMouseRelease;
};

#endif // TRAY_POPUP_H
