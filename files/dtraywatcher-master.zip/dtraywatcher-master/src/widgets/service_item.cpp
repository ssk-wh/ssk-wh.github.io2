#include "service_item.h"

ServiceItem::ServiceItem(const QString &text, QObject *parent)
    : QObject(parent)
    , m_text(text)
{

}

void ServiceItem::setText(const QString &text)
{
    if (m_text == text)
        return;

    m_text = text;
    Q_EMIT textChanged(text);
}

void ServiceItem::setActionIcon(QString actionIcon)
{
    if (m_actionIcon != actionIcon) {
        m_actionIcon = actionIcon;
    }

    Q_EMIT actionIconChanged(actionIcon);
}

void ServiceItem::setLeftIcon(QString leftIcon)
{
    if (m_leftIcon != leftIcon) {
        m_leftIcon = leftIcon;
    }

    Q_EMIT leftIconChanged(leftIcon);
}

void ServiceItem::setRightIcon(QString rightIcon)
{
    if (m_rightIcon != rightIcon) {
        m_rightIcon = rightIcon;
    }

    Q_EMIT rightIconChanged(rightIcon);
}

void ServiceItem::setHoverIcon(QString hoverIcon)
{
    if (m_hoverIcon != hoverIcon) {
        m_hoverIcon = hoverIcon;
    }

    Q_EMIT hoverIconChanged(hoverIcon);
}
