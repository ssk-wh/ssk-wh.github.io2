#include "service_slider.h"

ServiceSlider::ServiceSlider(QObject *parent)
    : QObject(parent)
    , m_min(0)
    , m_max(0)
    , m_value(0)
    , m_mute(false)
{

}

void ServiceSlider::setValue(int value)
{
    if (m_value == value)
        return;

    m_value = value;

    Q_EMIT valueChanged(value);
}

void ServiceSlider::setMute(int mute)
{
    if (m_mute == mute)
        return;

    m_mute = mute;

    Q_EMIT muteChanged(mute);
}

void ServiceSlider::setMin(int min)
{
    if (m_min != min) {
        m_min = min;
    }

    Q_EMIT minChanged(min);
}

void ServiceSlider::setMax(int max)
{
    if (m_max != max) {
        m_max = max;
    }

    Q_EMIT maxChanged(max);
}

void ServiceSlider::setLeftIcon(QString leftIcon)
{
    if (m_leftIcon != leftIcon) {
        m_leftIcon = leftIcon;
    }

    Q_EMIT leftIconChanged(leftIcon);
}

void ServiceSlider::setRightIcon(QString rightIcon)
{
    if (m_rightIcon != rightIcon) {
        m_rightIcon = rightIcon;
    }

    Q_EMIT rightIconChanged(rightIcon);
}
