#include "service_title_item.h"

ServiceTitleItem::ServiceTitleItem(const QString &title, const QString &content, QObject *parent)
    : QObject(parent)
    , m_title(title)
    , m_content(content)
{

}

void ServiceTitleItem::setTitle(const QString &title)
{
    if (m_title == title)
        return;

    m_title = title;
    Q_EMIT titleChanged(title);
}

void ServiceTitleItem::setContent(const QString &content)
{
    if (m_content == content)
        return;

    m_content = content;
    Q_EMIT contentChanged(content);
}
