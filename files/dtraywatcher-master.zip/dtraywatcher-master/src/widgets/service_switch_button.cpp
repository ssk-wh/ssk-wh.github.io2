#include "service_switch_button.h"

#include <QTimer>
ServiceSwitchButton::ServiceSwitchButton(const QString &title, QObject *parent)
    : QObject(parent)
    , m_title(title)
    , m_open(false)
{

}

void ServiceSwitchButton::setOpen(bool open)
{
    if (m_open == open)
        return;

    m_open = open;
    Q_EMIT openChanged(open);
}
