#include "service_separator.h"

ServiceSeparator::ServiceSeparator(QObject *parent)
    : QObject(parent)
{

}
