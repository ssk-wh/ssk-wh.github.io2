#include "service_text.h"

ServiceText::ServiceText(const QString &text, QObject *parent)
    : QObject(parent)
    , m_text(text)
{

}

void ServiceText::setText(const QString &text)
{
    if (m_text == text)
        return;

    m_text = text;
    Q_EMIT textChanged(text);
}
