#ifndef MANAGER_H
#define MANAGER_H

#include <QObject>
#include <QMap>
#include <QDBusContext>

#include <dtkwidget_global.h>

class QDBusServiceWatcher;
//class ServiceHandler;
DWIDGET_USE_NAMESPACE

class Watcher : public QObject , public QDBusContext
{
    Q_OBJECT
    Q_PROPERTY(QStringList Services READ Services NOTIFY ServicesChanged)
    Q_PROPERTY(QString Version READ Version)

public:
    ~ Watcher();

    static Watcher *instance();

    bool RegisterService(const QString &service);
    QStringList Services() const;
    QString Version() const;

Q_SIGNALS:
    void ServiceRegistered(const QString &service);
    void ServiceUnregistered(const QString &service);
    void ServicesChanged(const QStringList &services);

private:
    Watcher(QObject *parent = nullptr);

private Q_SLOTS:
    void onServiceRegistered(const QString &service);
    void onServiceUnregistered(const QString &service);

private:
    QMap<QString, QDBusServiceWatcher *> m_servicesMap;
};

#endif // MANAGER_H
