#include <DApplication>
#include <DMainWindow>
#include <DWidgetUtil>
#include <DApplicationSettings>
#include <DTitlebar>
#include <DProgressBar>
#include <DFontSizeManager>
#include <DLog>

#include <QPropertyAnimation>
#include <QDate>
#include <QLayout>
#include <QDBusConnection>

#include "dbus_adapter.h"
#include "watcher.h"
#include "tray_panel.h"

DWIDGET_USE_NAMESPACE
DCORE_USE_NAMESPACE

int main(int argc, char *argv[])
{
    QGuiApplication::setAttribute(Qt::AA_UseHighDpiPixmaps);
    DApplication a(argc, argv);
    a.setOrganizationName("deepin");
    a.setApplicationName("traywatcher");

    DLogManager::registerFileAppender();
    DLogManager::registerConsoleAppender();

    // 设置颜色
    DGuiApplicationHelper::setAttribute(DGuiApplicationHelper::UseInactiveColorGroup, false);

    TrayPanel panel;
    panel.setMinimumSize(400, 100);
    QObject::connect(Watcher::instance(), &Watcher::ServiceRegistered, &panel, &TrayPanel::addItem, Qt::QueuedConnection);
    QObject::connect(Watcher::instance(), &Watcher::ServiceUnregistered, &panel, &TrayPanel::removeItem, Qt::QueuedConnection);
    DBusAdapter adapter(Watcher::instance());

    auto sessionBus = QDBusConnection::sessionBus();
    const QString &service = adapter.metaObject()->classInfo(0).value();
    const QString &path = adapter.metaObject()->classInfo(1).value();
    const QString &interface = adapter.metaObject()->classInfo(2).value();

    bool res = sessionBus.registerService(service);
    if (!res) {
        qFatal("TODO");
    }

    res = sessionBus.registerObject(path, interface, Watcher::instance());
    if (!res) {
        qFatal("TODO");
    }

    panel.show();

    return a.exec();
}
