#include "client_adapter.h"

#include <QDebug>
#include <QFileSystemWatcher>
#include <QDir>
#include <QDBusMetaType>

#include <DDBusSender>
#include <DDesktopServices>

DWIDGET_USE_NAMESPACE

const QString TrashDir = QDir::homePath() + "/.local/share/Trash";
const QDir::Filters ItemsShouldCount = QDir::AllEntries | QDir::Hidden | QDir::System | QDir::NoDotAndDotDot;

ClientAdapter::ClientAdapter(QObject *parent)
    : QObject(parent)
    , m_fsWatcher(new QFileSystemWatcher(this))
{
    qDBusRegisterMetaType<QMap<QString, QString>>();

    connect(m_fsWatcher, &QFileSystemWatcher::directoryChanged, this, &ClientAdapter::onTrashStatusChanged, Qt::QueuedConnection);
    onTrashStatusChanged();
}

QStringList ClientAdapter::Items() const
{
    return m_items;
}

QString ClientAdapter::Tips() const
{
    return m_tips;
}

QString ClientAdapter::Icon() const
{
    return m_icon;
}

void ClientAdapter::activate()
{
    DDesktopServices::showFolder(QUrl("trash:///"));
}

bool ClientAdapter::acceptFormats(const QStringList &formats)
{
    if (formats.contains("RequestDock")) {
        if (!formats.contains("Removable")) {
            return false;
        } else {
            return true;
        }
    }

    if (!formats.contains("text/uri-list"))
        return false;

    return true;
}

void ClientAdapter::handleMimeData(const QMap<QString, QString> &map)
{   
    if (map.keys().contains("RequestDock")) {
        auto appKey = map.value("AppKey");
        DDBusSender()
                .service("com.deepin.dde.Launcher")
                .path("/com/deepin/dde/Launcher")
                .interface("com.deepin.dde.Launcher")
                .method("UninstallApp")
                .arg(appKey)
                .call();
    }

    if (map.keys().contains("text/uri-list")) {
        const QString &url = map.value("text/uri-list");
        auto urls = url.split('\n');
        QStringList fileUrls;
        for (auto u : urls) {
            if (!u.trimmed().isEmpty()) {
                const QFileInfo& info = QUrl(u.trimmed()).toLocalFile();
                fileUrls << info.absoluteFilePath();
            }
        }

        DDBusSender()
                .service("org.freedesktop.FileManager1")
                .path("/org/freedesktop/FileManager1f")
                .interface("org.freedesktop.FileManager1")
                .method("Trash")
                .arg(QStringList() << "/home/uos/Desktop/123.doc")
                .call();
    }
}

void ClientAdapter::moveToTrash(const QList<QUrl> &urlList)
{
    QStringList argumentList;
    for (const QUrl &url : urlList) {
        const QFileInfo& info = url.toLocalFile();
        argumentList << info.absoluteFilePath();
    }

    //    m_fileManagerInter->Trash(argumentList);
}

void ClientAdapter::onTrashStatusChanged()
{
    const bool dirExists = QDir(TrashDir + "/files").exists();
    m_fsWatcher->addPath(TrashDir);
    if (dirExists) {
        m_fsWatcher->addPath(TrashDir + "/files");
    }

    if (!dirExists) {
        m_tips = tr("Empty");
        m_icon = "user-trash";
    } else {
        int count = QDir(TrashDir + "/files").entryList(ItemsShouldCount).count();
        if (count == 0) {
            m_tips = tr("Empty");
            m_icon = "user-trash";
        } else {
            m_tips = QString(tr("回收站-%1个文件")).arg(count);
            m_icon = "user-trash-full";
        }}

    Q_EMIT tipsChanged(m_tips);
    Q_EMIT iconChanged(m_icon);
}
