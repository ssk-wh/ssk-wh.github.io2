#ifndef CLIENT_ADAPTER_H
#define CLIENT_ADAPTER_H

#include <QObject>
#include <QMap>
#include <QUrl>

class QFileSystemWatcher;

class ClientAdapter : public QObject
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.deepin.trayitem")

public:
    ClientAdapter(QObject *parent = nullptr);

    Q_PROPERTY(QStringList Items READ Items)
    QStringList Items() const;

    Q_PROPERTY(QString Tips READ Tips)
    QString Tips() const;

    Q_PROPERTY(QString Icon READ Icon)
    QString Icon() const;

public Q_SLOTS:
    void activate();
    // TODO 支持右键菜单

    // 支持处理拖拽事件
    bool acceptFormats(const QStringList &formats);
    void handleMimeData(const QMap<QString, QString> &map);

private Q_SLOTS:
    void onTrashStatusChanged();
    void moveToTrash(const QList<QUrl> &urlList);

Q_SIGNALS:
    void itemsChanged(const QStringList &services);
    void tipsChanged(const QString &tips);
    void iconChanged(const QString &tips);

private:
    QStringList m_items;
    QString m_tips;
    QString m_icon;
    QFileSystemWatcher *m_fsWatcher;
};

#endif // CLIENT_ADAPTER_H
