#ifndef CLIENT_ADAPTER_H
#define CLIENT_ADAPTER_H

#include <QObject>

class ClientAdapter : public QObject
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.deepin.trayitem")

public:
    ClientAdapter(QObject *parent = nullptr);

    Q_PROPERTY(QStringList Items READ Items)
    QStringList Items() const;

    Q_PROPERTY(QString Tips READ Tips)
    QString Tips() const;

    Q_PROPERTY(QString Icon READ Icon)
    QString Icon() const;

public Q_SLOTS:
    void Activate();
    // TODO 支持右键菜单

Q_SIGNALS:
    void itemsChanged(const QStringList &services);
    void tipsChanged(const QString &tips);
    void iconChanged(const QString &tips);

private:
    QStringList m_items;
};

#endif // CLIENT_ADAPTER_H
