#include "client_adapter.h"

#include <QDebug>

#include <DDBusSender>

ClientAdapter::ClientAdapter(QObject *parent)
    : QObject(parent)
{

}

QStringList ClientAdapter::Items() const
{
    return m_items;
}

QString ClientAdapter::Tips() const
{
    return QString(tr("deepin-system-monitor"));
}

QString ClientAdapter::Icon() const
{
    return "deepin-system-monitor";
}

void ClientAdapter::Activate()
{
    DDBusSender()
            .service("com.deepin.SystemMonitorPluginPopup")
            .path("/com/deepin/SystemMonitorPluginPopup")
            .interface("com.deepin.SystemMonitorPluginPopup")
            .method("slotShowOrHideSystemMonitorPluginPopupWidget")
            .call();
}
