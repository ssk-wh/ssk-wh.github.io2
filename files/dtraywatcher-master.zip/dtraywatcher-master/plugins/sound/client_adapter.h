#ifndef CLIENT_ADAPTER_H
#define CLIENT_ADAPTER_H

#include <QObject>
#include <QMap>

#include <QDBusMessage>

#include "sound_model.h"

//class QStorageInfo;
class ServiceSlider;
class ClientAdapter : public QObject
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.deepin.trayitem")

public:
    ClientAdapter(QObject *parent = nullptr);

    Q_PROPERTY(QStringList Items READ Items)
    QStringList Items() const;

    Q_PROPERTY(QString Tips READ Tips)
    QString Tips() const;

    Q_PROPERTY(QString Icon READ Icon NOTIFY iconChanged)
    QString Icon() const;

Q_SIGNALS:
    void itemsChanged(const QStringList &services);
    void tipsChanged(const QString &tips);
    void iconChanged(const QString &icon);

private Q_SLOTS:
    void onPortAdded(Port port);
    void onPortRemoved(Port port);

private:
    QStringList m_items;
    SoundModel *m_model;

    QMap<Port, QPair<QString/*path*/, ServiceSlider *>> m_portMap;
//    QList<Port> m_ports;
};

#endif // CLIENT_ADAPTER_H
