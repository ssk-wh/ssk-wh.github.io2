#ifndef SOUND_MODEL_H
#define SOUND_MODEL_H

#include <QObject>

#include <com_deepin_daemon_audio.h>
#include <com_deepin_daemon_audio_sink.h>

using DBusAudio = com::deepin::daemon::Audio;
using DBusSink = com::deepin::daemon::audio::Sink;

struct Port
{
    enum Direction {
        Out = 1,
        In = 2
    };

    QString id;
    QString name;
    uint cardId;
    QString cardName;
    bool enable;
    Direction direction;

    bool operator==(const Port &other) {
        return (this->id == other.id
                && this->name == other.name
                && this->cardId == other.cardId
                && this->cardName == other.cardName
                && this->enable == other.enable
                && this->direction == other.direction);
    }

//    bool operator<(Port *other) {
//        return name < other->name;
//    }
};

inline bool operator<(const Port p1, const Port p2) { return p1.name < p2.name;}

class SoundModel : public QObject
{
    Q_OBJECT
public:
    explicit SoundModel(QObject *parent = nullptr);

    inline QList<Port> ports() {return m_ports;}

    double currentVolume();
    bool currentMute();
    bool volumnEnhance();

public Q_SLOTS:
    void setCurrentVolumn(double volumn);
    void setCurrentMute(bool mute);

Q_SIGNALS:
    void currnetVolumeChanged(double value) const;
    void currentMuteChanged(bool mute) const;
    void volumeEnhanceChanged(bool enable) const;         // 开启音量增强

    void portAdded(Port port);
    void portRemoved(Port port);

private:
    void initConnection();

private Q_SLOTS:
    void onDefaultSinkChanged(const QDBusObjectPath &path);
    void onPortEnabledChanged(uint cardId, const QString &portId, bool enable);
    void onCardsWithoutUnavailableChanged(const QString &json);

private:
    DBusAudio *m_audioInter;
    DBusSink *m_defSinkInter;

    QList<Port> m_ports;
};

#endif // SOUND_MODEL_H
