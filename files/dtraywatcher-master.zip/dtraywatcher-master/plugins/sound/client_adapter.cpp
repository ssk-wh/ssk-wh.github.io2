#include "client_adapter.h"
#include "service_text.h"
#include "service_slider.h"
#include "service_title_item.h"
#include "util.h"

#include <QDebug>
#include <QTimer>

ClientAdapter::ClientAdapter(QObject *parent)
    : QObject(parent)
    , m_model(new SoundModel(this))
{
    ServiceTitleItem *title = new ServiceTitleItem(tr("Device"), QString("%1%").arg(m_model->currentVolume() * 100), this);
    connect(m_model, &SoundModel::currnetVolumeChanged, title, [ = ] (double volumn) {
        title->setContent(QString("%1%").arg(volumn * 100));
    });
    auto btn_path = Util::bind(title);
    m_items.append(btn_path);

    connect(m_model, &SoundModel::portAdded, this, &ClientAdapter::onPortAdded);
    connect(m_model, &SoundModel::portRemoved, this, &ClientAdapter::onPortRemoved);

    // handle ports
    for (auto p : m_model->ports()) {
        onPortAdded(p);
    }

    QMetaObject::invokeMethod(this, [ = ] {
        Q_EMIT itemsChanged(m_items);
    }, Qt::QueuedConnection);
}

QStringList ClientAdapter::Items() const
{
    return m_items;
}

QString ClientAdapter::Tips() const
{
    return tr("Volumn");
}


void ClientAdapter::onPortAdded(Port port)
{
    ServiceSlider *slider = new ServiceSlider(this);

    slider->setMin(0);
    slider->setMax(m_model->volumnEnhance() ? 150 : 100);
    slider->setValue(int(m_model->currentVolume() * 100.0));

    connect(m_model, &SoundModel::volumeEnhanceChanged, this, [ = ] (bool enhance) {
        slider->setMax(enhance ? 150 : 100);
        slider->setValue(int(m_model->currentVolume() * 100.0));
    });
    connect(m_model, &SoundModel::currnetVolumeChanged, slider, [ = ] (double volumn) {
        slider->setValue(int(volumn * 100.0));
    });
    connect(m_model, &SoundModel::currentMuteChanged, slider, &ServiceSlider::setMute);

    connect(slider, &ServiceSlider::valueChanged, m_model, [ = ] (int value) {
        double volumn = value*1.0 / 100;
        m_model->setCurrentVolumn(volumn);
    });

    connect(slider, &ServiceSlider::muteChanged, m_model, &SoundModel::setCurrentMute);

    auto path = Util::bind(slider);
    QPair<QString/*path*/, ServiceSlider *> pair;
    pair.first = path;
    pair.second = slider;
    m_portMap.insert(port, pair);

    m_items.append(path);

    Q_EMIT itemsChanged(m_items);
}

void ClientAdapter::onPortRemoved(Port port)
{
    auto pair = m_portMap.value(port);

    // 取消path的注册
    Util::Unregister(pair.first);

    // 内存释放
    delete pair.second;

    // 清除数据
    m_portMap.remove(port);
    m_items.removeOne(pair.first);
}

QString ClientAdapter::Icon() const
{
    return "indicator-sound-switcher";
}
