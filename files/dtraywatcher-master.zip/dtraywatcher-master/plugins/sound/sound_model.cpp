#include "sound_model.h"

SoundModel::SoundModel(QObject *parent)
    : QObject(parent)
    , m_audioInter(new DBusAudio("com.deepin.daemon.Audio", "/com/deepin/daemon/Audio", QDBusConnection::sessionBus(), this))
    , m_defSinkInter(nullptr)
{
    initConnection();

    // init
    onDefaultSinkChanged(m_audioInter->defaultSink());
    onCardsWithoutUnavailableChanged(m_audioInter->cardsWithoutUnavailable());
}

double SoundModel::currentVolume()
{
    return m_defSinkInter ? m_defSinkInter->volume() : 0;
}

void SoundModel::setCurrentVolumn(double volumn)
{
    if (m_defSinkInter)
        m_defSinkInter->SetVolume(volumn, true);

    // 如果此时静音，则取消静音状态
    if (m_defSinkInter->mute())
        m_defSinkInter->SetMuteQueued(false);
}

bool SoundModel::currentMute()
{
    return m_defSinkInter ? m_defSinkInter->mute() : false;
}

void SoundModel::setCurrentMute(bool mute)
{
    if (m_defSinkInter) {
        m_defSinkInter->SetMute(mute);
    }
}

bool SoundModel::volumnEnhance()
{
    return m_audioInter->increaseVolume();
}

void SoundModel::initConnection()
{
    connect(m_audioInter, &DBusAudio::DefaultSinkChanged, this, &SoundModel::onDefaultSinkChanged);
    connect(m_audioInter, &DBusAudio::IncreaseVolumeChanged, this, &SoundModel::volumeEnhanceChanged);
    connect(m_audioInter, &DBusAudio::PortEnabledChanged, this, &SoundModel::onPortEnabledChanged);
    connect(m_audioInter, &DBusAudio::CardsWithoutUnavailableChanged, this, &SoundModel::onCardsWithoutUnavailableChanged);
}

void SoundModel::onDefaultSinkChanged(const QDBusObjectPath &path)
{
    if (m_defSinkInter) {
        delete m_defSinkInter;
    }

    m_defSinkInter = new DBusSink("com.deepin.daemon.Audio", path.path(), QDBusConnection::sessionBus(), this);

    connect(m_defSinkInter, &DBusSink::VolumeChanged, this, &SoundModel::currnetVolumeChanged);
    connect(m_defSinkInter, &DBusSink::MuteChanged, this, &SoundModel::currentMuteChanged);

    currnetVolumeChanged(m_defSinkInter->volume());
    currentMuteChanged(m_defSinkInter->mute());
}

void SoundModel::onPortEnabledChanged(uint cardId, const QString &portId, bool enable)
{
    Q_UNUSED(cardId);
    Q_UNUSED(portId);
    Q_UNUSED(enable);

    // 关注服务的CardsWithoutUnavailableChanged属性变化即可
}

void SoundModel::onCardsWithoutUnavailableChanged(const QString &json)
{
    QList<Port> ports;

    QMap<uint, QStringList> tmpCardIds;

    QJsonDocument doc = QJsonDocument::fromJson(json.toUtf8());
    QJsonArray cards = doc.array();
    for (QJsonValue card : cards) {
        QJsonObject cardObj = card.toObject();
        const uint cardId = cardObj["Id"].toInt();
        const QString cardName = cardObj["Name"].toString();
        QJsonArray portArray = cardObj["Ports"].toArray();

        for (QJsonValue portValue : portArray) {
            QJsonObject portObj = portValue.toObject();
            const double portAvai = portObj["Available"].toDouble();

            // 0 Unknow 1 Not available 2 Available
            if (portAvai == 2 || portAvai == 0 ) {
                // 禁用的端口不显示
                if (!portObj["Enabled"].toBool())
                    continue;

                const QString portId = portObj["Name"].toString();
                const QString portName = portObj["Description"].toString();

                Port port;
                port.id = portId;
                port.name = portName;
                port.direction = Port::Direction(portObj["Direction"].toDouble());
                port.cardId = cardId;
                port.cardName = cardName;
                port.enable = portObj["Enabled"].toBool();

                ports.append(port);
            }
        }
    }

    // 避免接收者收到added或者removed信号就获取ports结果还是原来的数据
    auto oldList = m_ports;
    m_ports = ports;

    for (auto p : ports) {
        if (!oldList.contains(p)) {
            Q_EMIT portAdded(p);
        }
    }

    for (auto p : oldList) {
        if (!ports.contains(p)) {
            Q_EMIT portRemoved(p);
        }
    }
}
