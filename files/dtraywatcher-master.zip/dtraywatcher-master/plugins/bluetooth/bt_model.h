#ifndef BT_MODEL_H
#define BT_MODEL_H

#include <QObject>

class QTimer;
class BtModel : public QObject
{
    Q_OBJECT
public:
    explicit BtModel(QObject *parent = nullptr);

    QString name();

    bool powered() const;
    void setPowered(bool on);

    const QStringList &items();

Q_SIGNALS:
    void poweredChanged(bool on);
    void itemsChanged(const QStringList &list);

private:
    bool m_powered;
    QStringList m_itemList;

    QTimer *m_timer;
};

#endif // BT_MODEL_H
