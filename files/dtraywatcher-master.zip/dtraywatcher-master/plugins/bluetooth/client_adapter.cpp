#include "client_adapter.h"
#include "service_text.h"
#include "service_switch_button.h"
#include "service_separator.h"
#include "util.h"
#include "bt_model.h"

#include <QDebug>
#include <QTimer>

ClientAdapter::ClientAdapter(QObject *parent)
    : QObject(parent)
    , m_model(new BtModel(this))
{
    QTimer::singleShot(3000, this, [ = ] {
        m_model->setPowered(true);
    });

    ServiceSwitchButton *button = new ServiceSwitchButton(m_model->name(), this);
    button->setOpen(m_model->powered());
    m_items.append(Util::bind(button));

    ServiceSeparator *separator = new ServiceSeparator(this);
    m_items.append(Util::bind(separator));

    connect(m_model, &BtModel::poweredChanged, button, &ServiceSwitchButton::setOpen);
    connect(button, &ServiceSwitchButton::openChanged, m_model, &BtModel::setPowered);
    connect(m_model, &BtModel::itemsChanged, this, [ = ] (const QStringList &list) {
        // 先解绑
        int oldCount = m_items.count();
        for (int i = 1; i < oldCount; ++i) {
            Util::unbind(m_items.at(i));
        }

        for (int i = 1; i < oldCount; ++i) {
            m_items.removeAt(1);
        }

        // 再绑定新内容
        for (int i = 0; i < list.size(); ++i) {
            auto path = Util::bind(new ServiceText(list.at(i)));
            m_items.append(path);
        }
        Q_EMIT itemsChanged(m_items);
    });
}

QStringList ClientAdapter::Items() const
{
    return m_items;
}

QString ClientAdapter::Tips() const
{
    return m_model->name();
}

QString ClientAdapter::Icon() const
{
    return "bluetooth";
}

