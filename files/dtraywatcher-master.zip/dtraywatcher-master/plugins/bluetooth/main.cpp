#include <DApplication>
#include <DMainWindow>
#include <DWidgetUtil>
#include <DApplicationSettings>
#include <DTitlebar>
#include <DProgressBar>
#include <DFontSizeManager>
#include <DLog>

#include <QPropertyAnimation>
#include <QDate>
#include <QLayout>
#include <QDBusConnection>
#include <QDBusInterface>
#include <QDBusReply>
#include <QTimer>

#include <QDBusServiceWatcher>
#include <QDBusConnectionInterface>

#include "client_adapter.h"

#include <unistd.h>

DWIDGET_USE_NAMESPACE
DCORE_USE_NAMESPACE

int main(int argc, char *argv[])
{
    QGuiApplication::setAttribute(Qt::AA_UseHighDpiPixmaps);
    DApplication a(argc, argv);
    a.setOrganizationName("deepin");
    a.setApplicationName("dtray-bluetooth");

    DLogManager::registerFileAppender();
    DLogManager::registerConsoleAppender();

    auto sessionBus = QDBusConnection::sessionBus();
    const QString &service = "org.deepin.trayitem-" + QString::number(getpid());

    // 注册DBus
    bool res = sessionBus.registerService(service);
    if (!res) {
        qFatal("%s", sessionBus.lastError().message().toLatin1().data());
    }

    ClientAdapter adapter;
    res = sessionBus.registerObject("/ItemNotifier", &adapter, QDBusConnection::ExportAllProperties | QDBusConnection::ExportAllSignals | QDBusConnection::ExportAllSlots);
    if (!res) {
        qFatal("%s", sessionBus.lastError().message().toLatin1().data());
    }

    // 注册服务
    if (sessionBus.interface()->isServiceRegistered("org.deepin.traywatcher")) {
        QDBusInterface interface("org.deepin.traywatcher", "/traywatcher", "org.deepin.traywatcher", QDBusConnection::sessionBus());
        QDBusReply<bool> reply = interface.call("RegisterService", service);
        qDebug() << "register result: "<< reply.value();
        if (reply.error().type() != QDBusError::NoError)
            qDebug() << reply.error().message();
    }

    QDBusServiceWatcher *watcher = new QDBusServiceWatcher;
    watcher->setConnection(sessionBus);
    watcher->addWatchedService("org.deepin.traywatcher");
    QObject::connect(watcher, &QDBusServiceWatcher::serviceRegistered, [ = ] {
        qDebug() << "try registered...";
        QDBusInterface interface("org.deepin.traywatcher", "/traywatcher", "org.deepin.traywatcher", QDBusConnection::sessionBus());
        QDBusReply<bool> reply = interface.call("RegisterService", service);
        qDebug() << "register result: "<< reply.value();
        if (reply.error().type() != QDBusError::NoError)
            qDebug() << reply.error().message();
        else {
            qDebug() << "registered!";
        }
    });
    QObject::connect(watcher, &QDBusServiceWatcher::serviceUnregistered, [ = ] (const QString &service) {
        qDebug() << "service: " << service << " unregistered";
        watcher->addWatchedService(service);
    });

    return a.exec();
}
