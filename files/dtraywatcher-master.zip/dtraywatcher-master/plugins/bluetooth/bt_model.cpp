#include "bt_model.h"

#include <QTimer>
#include <QRandomGenerator>

BtModel::BtModel(QObject *parent)
    : QObject(parent)
    , m_powered(false)
    , m_timer(new QTimer(this))
{
    m_timer->setInterval(1000);

    auto rand = new QRandomGenerator();
    connect(m_timer, &QTimer::timeout, this, [ = ] {
        quint32 c = rand->generate();
        m_itemList.clear();
        for (int i = 0; i < int(c % 20); ++i) {
            m_itemList.append("device" + QString::number(i));
        }
        Q_EMIT itemsChanged(m_itemList);
        m_timer->setInterval(rand->generate() % 1000);
    });
}

QString BtModel::name()
{
    return "fpc-PC";
}

bool BtModel::powered() const
{
    return m_powered;
}

void BtModel::setPowered(bool on)
{
    if (m_powered == on)
        return;

    m_powered = on;
    Q_EMIT poweredChanged(on);

    // 模拟打开蓝牙后,扫描到了很多设备的情况
    if (on) {
        for (int i = 0; i < 10; ++i) {
            m_itemList.append("device" + QString::number(i));
            Q_EMIT itemsChanged(m_itemList);
        }
        m_timer->start();
    } else {
        m_itemList.clear();
        Q_EMIT itemsChanged(m_itemList);
        m_timer->stop();
    }
}
