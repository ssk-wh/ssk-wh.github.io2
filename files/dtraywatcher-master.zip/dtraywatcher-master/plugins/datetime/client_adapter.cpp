#include "client_adapter.h"
#include "service_text.h"
#include "util.h"
#include "service_title_item.h"

#include <QDebug>
#include <QTimer>
#include <QDateTime>

QString currentTimeString() {
    return QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
}

ClientAdapter::ClientAdapter(QObject *parent)
    : QObject(parent)
    , m_tips(currentTimeString())
{
    ServiceText *text = new ServiceText(currentTimeString(), this);
    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, [ = ] {
        m_tips = currentTimeString();
        text->setText(m_tips);
        Q_EMIT tipsChanged(m_tips);
    });
    timer->start(1000);
    m_items.append(Util::bind(text));

    QMetaObject::invokeMethod(this, [ = ] {
        Q_EMIT itemsChanged(m_items);
    }, Qt::QueuedConnection);
}

QStringList ClientAdapter::Items() const
{
    return m_items;
}

QString ClientAdapter::Tips() const
{
    return m_tips;
}

QString ClientAdapter::Icon() const
{
    return "unity-datetime-panel";
}
